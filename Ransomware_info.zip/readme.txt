由于查询需要会对注册表项内容查询，会触发杀软防护规则
运行前强烈要求把杀软退出

Windows系统要求：
请务必以管理员身份运行

32位系统请运行Ransomware_info_x86.exe

64位系统请运行Ransomware_info_x64.exe

所有结果都在在output文件夹里

自动通过7za.exe把output文件夹压缩为output.7z大大减少文件大小方便传输




Windows system requirements:
Please run as administrator

For 32-bit systems, please run Ransomware_info_x86.exe

For 64-bit systems, please run Ransomware_info_x64.exe

All results are in the output folder

Automatically compress the output folder to a file size of output.7z for easy transmission

