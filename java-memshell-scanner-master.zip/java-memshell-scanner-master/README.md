## 0x01 简介
通过jsp脚本扫描并查杀各类中间件内存马，比Java agent要温和一些。

## 0x02 截图
![Tomcat内存马扫描结果展示](doc/tomcat-memshell-scanner.png)

## 0x03 更多
[Filter/Servlet型内存马的扫描抓捕与查杀](https://gv7.me/articles/2020/filter-servlet-type-memshell-scan-capture-and-kill/)